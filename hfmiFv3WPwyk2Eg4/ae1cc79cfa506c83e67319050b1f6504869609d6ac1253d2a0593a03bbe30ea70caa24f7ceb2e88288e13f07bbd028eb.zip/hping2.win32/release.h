/* 
 * $smu-mark$ 
 * $name: release.h$
 * $author: Salvatore Sanfilippo <antirez@invece.org>$
 * $copyright: Copyright (C) 1999 by Salvatore Sanfilippo$
 * $license: This software is under GPL version 2 of license$
 * $date: Fri Nov  16 11:55:49 MET 1999$
 * $rev: 17$
 */ 

#ifndef _RELEASE_H
#define _RELEASE_H

#define RELEASE_VERSION "2.0.0-b1 Support for XP SP2"
#define RELEASE_DATE "Fri May  24 2006"
#define CONTACTS "<antirez@invece.org> <james.v.fields@gmail.com> <kjohnson@secureideas.net>"

#endif /* _RELEASE_H */
