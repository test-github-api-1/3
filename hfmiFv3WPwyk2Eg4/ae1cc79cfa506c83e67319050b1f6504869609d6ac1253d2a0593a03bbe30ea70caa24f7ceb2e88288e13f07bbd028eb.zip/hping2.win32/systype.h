#ifndef __SYSTYPE_H
#define __SYSTYPE_H

#define OSTYPE_WIN32

#endif /* SYSTYPE_H */
