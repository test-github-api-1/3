# hcChatClient
Development repository for the latest hack.chat client
