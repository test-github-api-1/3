## Explanation
This folder will contain the source for the version 2 client. The new client has a build process which will transpile into `./client`. For now it is a placeholder that retains the development process flow for hack.chat's modular project structure.
