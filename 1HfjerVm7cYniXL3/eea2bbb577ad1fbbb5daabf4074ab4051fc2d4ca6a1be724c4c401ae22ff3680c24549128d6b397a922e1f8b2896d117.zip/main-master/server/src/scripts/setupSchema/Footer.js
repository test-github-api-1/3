/**
  * This script will be run once all questions have finished and no errors have
  * occured. You can congratulate the user on their fine choice in software usage
  *
  */

console.log('');
console.log('Config generated! You may now start the server normally.');
console.log('');
