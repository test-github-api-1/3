/*
  Description: This module is only in place to supress error notices legacy sources may get
*/

// module main
exports.run = async (core, server, socket, data) => {
  return;
};

// module meta
exports.info = {
  name: 'ping',
  description: 'This module is only in place to supress error notices legacy sources may get'
};
