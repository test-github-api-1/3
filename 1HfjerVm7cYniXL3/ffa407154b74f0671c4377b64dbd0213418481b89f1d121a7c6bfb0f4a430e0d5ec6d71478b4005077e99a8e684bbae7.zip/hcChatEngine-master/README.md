# hcChatEngine
The core JS chat engine for hack.chat, compatible with both browsers and nodejs
